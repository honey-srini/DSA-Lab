# 04 Queues
1. Write a program to implement a linear queue using array.
2. Write a program to implement a linked queue.
3. Write a program to implement a circular queue.
4. Write a program to implement input and output restricted deques.
5. Write a program to implement a priority queue.
6. Write a program to implement multiple queues.
7. Write a program which finds the solution of Josephus problem using a circular linked list.
8. Write a program to calculate the number of items in a queue.
9. Write a program to implement a dequeue with the help of a linked list.
10. Write a program to create a queue from a stack.
11. Write a program to create a stack from a queue.
12. Write a program to reverse the elements of a queue.
13. Write a program to input two queues and compare their contents