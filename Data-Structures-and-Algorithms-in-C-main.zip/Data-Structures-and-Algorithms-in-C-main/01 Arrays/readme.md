# 01 Arrays
1. Write a program to read and display n numbers using an array.
2. Write a program to find the average of n numbers using arrays.
3. Write a program to print the position of the smallest number of n numbers using arrays.
4. Write a program to find the second largest of n numbers using an array.
5. Write a program to find whether the array of integers contains a duplicate number.
6. Write a program to insert a number at a given location in an array.
7. Write a program to insert a number in an array that is already sorted in ascending order.
8. Write a program to delete a number from a given location in an array.
9. Write a program to delete a number from an array that is already sorted in ascending order.
10. Write a program to merge two unsorted arrays.
11. Write a program to merge two sorted arrays.
12. Write a program to read an array of n numbers and then find the smallest number using
functions.
13. Write a program to interchange the largest and the smallest number in an array using
functions.
14. Write a program that reads an array of 100 integers. Display all the pairs of elements whose
sum is 50.
15. Write a program to interchange the second element with the second last element.
16. Write a program to read and display a square (using functions).
17. Write a program to read two floating point number arrays. Merge the two arrays and display
the resultant array in reverse order.
18. Write a program to read a floating point array. Update the array to insert a new number at
the specified location