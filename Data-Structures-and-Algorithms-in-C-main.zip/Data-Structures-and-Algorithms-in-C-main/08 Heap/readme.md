# 08 Heap
1. Write a program to form a binary max-heap from the following sequence of data:
    ```
    50, 40, 35, 25, 20, 27, 33
    ```

2. Write a program to form a binary min-heap from the following sequence of data:
    ```
    50, 40, 35, 25, 20, 27, 33
    ```

3. Write a program to check if the given array is a min-heap or not 2, 3, 4, 5, 10 and 15.
4. Write a program to convert the given max heap into a min heap 9, 4, 7, 1, -2, 6 and 5.
5. Write a program to convert the given binary search tree into a min heap 5, 3, 8, 2, 4, 6 and 10.