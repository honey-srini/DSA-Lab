# 09 Graph

1.	Develop and Implement a Program for the following operations on Graph(G).<br>
    a. Create a Graph of N vertex using Adjacency Matrix.<br>
    b. Print all the nodes reachable from a given starting node in a digraph using DFS method
2.	Develop and Implement a Program for the following operations on Graph(G).<br>
    a. Create a Graph of N vertex using Adjacency Matrix.<br>
    b. Print all the nodes reachable from a given starting node in a digraph using BFS method
3.	Write a program to count the number of edges in the graph.
4.	Write a program to obtain the topological ordering of vertices in a digraph.
5.	Write a program to find the degree of each vertex In a graph.
